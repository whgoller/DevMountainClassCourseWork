DevMountain Pre-Assessment
=========

**Please complete this assessment within one week of receiving it.**

This repo contains all the neccessary information for the Pre Course assessment. 

The assessment is broken up into two parts. The first part is an HTML/CSS challenge that can be found with the code included in this repository. The second is a collection of JavaScript 'fiddles' described below. 
If you have and know git, go ahead and 'clone' this repo and get started. If you don't, click on the 'Download Zip' button to the right. 


Instructions.txt contains the neccessary instructions for the first HTML/CSS challenge. 

Below is a list of coding challenges that increase in difficulty. Although we don't expect you to finish all of them, we would love to see you take the challange and attempt them to see how far you can get.
When you finish each fiddle, click the 'update' button and that will create your own URL with your solution. Change the SOLUTION-URL with your new URL that contains the solution. 
Once you finish, zip up your code and email back to admin+assessment@devmounta.in

* [Name] - http://jsfiddle.net/U3ezV/ - http://jsfiddle.net/U3ezV/161/
* [Food] - http://jsfiddle.net/9Z3YG/ - http://jsfiddle.net/9Z3YG/141/
* [Double] - http://jsfiddle.net/hu85B/ - http://jsfiddle.net/hu85B/142/
* [Addition] - http://jsfiddle.net/M8pZf/ - http://jsfiddle.net/M8pZf/105/
* [First] - http://jsfiddle.net/zsFvE/ - http://jsfiddle.net/zsFvE/148/
* [Last] -  http://jsfiddle.net/hJZUE/ - http://jsfiddle.net/hJZUE/140/
* [Loop] - http://jsfiddle.net/YM7th/ - http://jsfiddle.net/YM7th/126/
* [numSum] - http://jsfiddle.net/b2ysK/ - http://jsfiddle.net/b2ysK/87/
* [oddsAndEvens] - http://jsfiddle.net/4zfcz/ - http://jsfiddle.net/4zfcz/121/
* [me] - http://jsfiddle.net/5Ua3r/ - http://jsfiddle.net/5Ua3r/93/
* [favoriteThings] - http://jsfiddle.net/zCcnT/ - http://jsfiddle.net/zCcnT/104/
* [firstLoop] - http://jsfiddle.net/Lgf3G/ - http://jsfiddle.net/Lgf3G/106/
* [userObj] - http://jsfiddle.net/VkvMV/ - http://jsfiddle.net/VkvMV/94/
